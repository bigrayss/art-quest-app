彩绘冒险精灵分层素材
================

大图：
- large_normal_body.png   1120x1120
- large_normal_paint.png  1120x1120
- large_happy_body.png    1120x1120
- large_happy_paint.png   1120x1120

小图示：
- icon_normal_body.png    256x256
- icon_normal_paint.png   256x256
- icon_happy_body.png     256x256
- icon_happy_paint.png    256x256

说明：
1. body 与 paint 每组像素完全对齐，可直接绝对定位叠加。
2. paint 文件为纯白剪影 + 透明背景，适合 CSS mask / filter / currentColor 方案染色。
3. 小图示为重新简化绘制，不是大图缩小，40px 使用时仍保留轮廓和表情识别度。
4. 所有 PNG 均无中文/英文说明文字烤入。
