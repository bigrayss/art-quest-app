彩绘精灵 04｜观察／探索 · 动效包

打开 index.html 查看 PNG + CSS 动画，或使用 embed.html 的最小组件。

这版以已确认 normal 角色为母版保留大眼睛、帽子、五官和身体比例，
结合新生成的放大镜与握持手，并作局部清理、重新组合及分层。
放大镜位于脸的右侧，不挡五官；镜片中间保留透明，仅有淡淡镜片色与反光。
这是局部二维动画，不是三维骨骼动画；没有录屏或把角色总图截图拆小。

画布与文件
- assets/04_explore.png：完整透明静态 PNG，1312 × 1199。
- assets/04_explore_closed.png：闭眼检查帧，同尺寸。
- assets/01_body.png：动画基础层，有留给眼睛、双脚活动的区域；不是完整角色。
- assets/01_body_tintable.png：可换颜料色的动画基础层。
- assets/02_magnifier_hand.png：放大镜与握持手，完整对齐画布。
- assets/03_rest_hand.png：另一只手，完整对齐画布。
- assets/04_feet_motion.png：双脚局部动画帧图，由原生分辨率局部变形生成。
- assets/05_blink_sprite.png：9 帧眨眼局部帧图。
- assets/06_body_clean.png：擦去身体颜料后的完整静态形象。
- assets/07_paint_mask.png：只有五处颜料的纯白透明遮罩，1312 × 1199。
- preview/04_explore_transparent.webp：透明循环动图，1312 × 1199，20 fps，6 秒。
- preview/04_explore_preview_warm.gif：暖白底展示预览，640 × 585，20 fps，6 秒。
- source/：保留母版与新生成道具来源，不用于正式组件直接显示。

动作
- 约每 3 秒眨眼一次，一次闭合到睁开约 0.3 秒。
- 放大镜和握持手一起小幅轻摆，另一只手及双脚轻微摆动。
- 身体、帽子、嘴、颜料固定，默认无整体浮动。
- 循环首尾衔接；没有地面阴影、彩色场景背景、文字或水印。

接入
1. 整个目录放到 static/mascot/04_explore/，不要和其他编号的 assets 混放。
2. 引入 mascot.css，复制 embed.html 中的 .mascot-04 节点。
3. 修改 HTML 的 src 为实际资源路径。CSS 图片路径相对于 CSS 文件。
4. 只调整外层 --mascot-width，例如 560px；不要分别挪动眼睛、手、脚。
5. 画布比例为 1312 / 1199；放大镜手和另一只手是全画布 PNG，定位已对齐。

控制类，与前两版及 03 保持一致
- no-blink：回到睁眼帧并停止眨眼。
- no-limbs：手脚与放大镜回到起始姿势并停止动作。
- 同时添加 no-blink 与 no-limbs：安静模式。
- is-paused：暂停在当前帧，可能停在半闭眼；不是安静模式。
- has-paint-color：启用身体颜料染色，--paint-color 设置颜色。
  例：<div class="mascot-04 has-paint-color" style="--paint-color:#428DD1;--mascot-width:560px">
- 不定义整体上下浮动，也不需要 with-float。
- 尊重 prefers-reduced-motion，系统减少动态时重置到静态姿势。

颜料
只有身体上的五处颜料会变色；帽子、腮红和放大镜不变。
独立白色遮罩保存在 assets/07_paint_mask.png。
演示 CSS 内嵌同一遮罩的数据，以便直接用 file:// 打开时也可预览染色。
生产环境可改成 mask-image:url('assets/07_paint_mask.png')，但要检查资源路径与同源规则。
所有对应全画布层都同尺寸、同位置；局部动作帧图的坐标见 rig.json。

使用场景
地图探索、观察类任务、查看画面细节。用户正在落笔时切换安静模式。
它表示陪伴观察，不表示评分或判断孩子画得好坏。

说明
GIF 为不透明预览，正式 PNG 与 WebP 才是透明素材。
PNG 保存了原生画布的细节；WebP 是便于播放的有损编码预览。
不要将 01_body.png 当完整图片使用，完整静态图请用 04_explore.png。
